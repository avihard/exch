package com.avi.exch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
